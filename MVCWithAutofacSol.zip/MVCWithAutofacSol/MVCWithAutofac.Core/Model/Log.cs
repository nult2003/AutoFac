﻿namespace MVCWithAutofac.Core.Model
{
    public class Log : BaseModel<int>
    {
        public string Action { get; set; }
    }
}